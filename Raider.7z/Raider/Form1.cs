﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raider
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Point lastpoint;
        private Point lastPoint;

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Clear();
        }

        private async Task SendScript(string script)
        {
            using (NamedPipeClientStream pipeClient = new NamedPipeClientStream(".", "SkibidiToiletSaidAUWAndNowSkibidiToiletSad", PipeDirection.Out))
            {
                try
                {
                    await pipeClient.ConnectAsync();

                    byte[] scriptBytes = Encoding.UTF8.GetBytes(script);

                    await pipeClient.WriteAsync(scriptBytes, 0, scriptBytes.Length);

                    pipeClient.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Fehler beim Senden des Scripts: {ex.Message}");
                }
            }
        }








        private void Attach_Click(object sender, EventArgs e)
        {
            Process.Start("Injector.exe");
        }

        private async void Execute_Click(object sender, EventArgs e)
        {
            string Script = fastColoredTextBox1.Text;
            await SendScript(Script);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
    }
}
